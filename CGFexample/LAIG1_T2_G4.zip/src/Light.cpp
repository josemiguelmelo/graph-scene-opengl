//
//  Light.cpp
//  CGFExample
//
//  Created by José Miguel  Melo on 17/10/14.
//  Copyright (c) 2014 me. All rights reserved.
//

#include "Light.h"
